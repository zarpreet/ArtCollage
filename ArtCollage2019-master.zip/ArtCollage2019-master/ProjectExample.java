public class ProjectExample {
	
	public static void main(String[]args) {
		Picture p = new Picture("");
		//p.show();
		Picture p2 = new Picture(p);
		p2.show();
	}

}